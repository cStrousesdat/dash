import StorageCard from "@/components/StorageCard";

const Index = () => {
  return <StorageCard />;
};

export default Index;
